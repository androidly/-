// src/lib.rs

use wasm_bindgen::prelude::*;
use num_integer::Integer; // <-- 导入 Integer trait 以使用 div_floor

// 可选的 panic hook
#[cfg(feature = "console_error_panic_hook")]
pub use console_error_panic_hook::set_once as set_panic_hook;

// 可选的 console log (如果启用了 debug_log feature)
#[cfg(feature = "debug_log")]
use web_sys::console;


fn generate2d_internal(
    x: i32,
    y: i32,
    ax: i32,
    ay: i32,
    bx: i32,
    by: i32,
    coordinates: &mut Vec<(u32, u32)>,
) {
    let w = (ax + ay).abs();
    let h = (bx + by).abs();

    let dax = ax.signum();
    let day = ay.signum();
    let dbx = bx.signum();
    let dby = by.signum();

    if h == 1 {
        let mut current_x = x;
        let mut current_y = y;
        for _ in 0..w {
            coordinates.push((current_x as u32, current_y as u32));
            current_x += dax;
            current_y += day;
        }
        return;
    }

    if w == 1 {
        let mut current_x = x;
        let mut current_y = y;
        for _ in 0..h {
            coordinates.push((current_x as u32, current_y as u32));
            current_x += dbx;
            current_y += dby;
        }
        return;
    }
    
    // 使用 div_floor 来匹配 JS 的 Math.floor(val / 2)
    // --- 修改点 开始 ---
    let mut ax2 = ax.div_floor(&2);
    let mut ay2 = ay.div_floor(&2);
    let mut bx2 = bx.div_floor(&2);
    let mut by2 = by.div_floor(&2);
    // --- 修改点 结束 ---

    let w2 = (ax2 + ay2).abs();
    let h2 = (bx2 + by2).abs();

    if 2 * w > 3 * h {
        if (w2 % 2 != 0) && (w > 2) {
            ax2 += dax;
            ay2 += day;
        }
        generate2d_internal(x, y, ax2, ay2, bx, by, coordinates);
        generate2d_internal(x + ax2, y + ay2, ax - ax2, ay - ay2, bx, by, coordinates);
    } else {
        if (h2 % 2 != 0) && (h > 2) {
            bx2 += dbx;
            by2 += dby;
        }
        generate2d_internal(x, y, bx2, by2, ax2, ay2, coordinates);
        generate2d_internal(x + bx2, y + by2, ax, ay, bx - bx2, by - by2, coordinates);
        generate2d_internal(
            x + (ax - dax) + (bx2 - dbx),
            y + (ay - day) + (by2 - dby),
            -bx2,
            -by2,
            -(ax - ax2),
            -(ay - ay2),
            coordinates,
        );
    }
}


fn gilbert2d_internal(width: u32, height: u32) -> Vec<(u32, u32)> {
    let mut coordinates: Vec<(u32, u32)> = Vec::new();
    let w_i32 = width as i32;
    let h_i32 = height as i32;

    if w_i32 >= h_i32 {
        generate2d_internal(0, 0, w_i32, 0, 0, h_i32, &mut coordinates);
    } else {
        generate2d_internal(0, 0, 0, h_i32, w_i32, 0, &mut coordinates);
    }

    // 调试日志：检查生成的坐标数量
    #[cfg(feature = "debug_log")]
    {
        console::log_1(&format!(
            "[Rust] gilbert2d_internal: width={}, height={}, expected_coords={}, generated_coords={}",
            width, height, width * height, coordinates.len()
        ).into());
        if coordinates.len() != (width * height) as usize {
            console::error_1(&"[Rust] Error: Coordinate count mismatch!".into());
        }
        // 可以在这里添加更多检查，比如坐标是否在范围内
        /*
        for (i, coord) in coordinates.iter().enumerate().take(5) { // 检查前5个
            console::log_1(&format!("[Rust] Coord {}: ({}, {})", i, coord.0, coord.1).into());
        }
        if !coordinates.is_empty() {
            let last_coord = coordinates.last().unwrap();
            console::log_1(&format!("[Rust] Last Coord: ({}, {})", last_coord.0, last_coord.1).into());
        }
        */
    }
    coordinates
}


#[wasm_bindgen]
pub fn wasm_encrypt(image_data_js: &[u8], width: u32, height: u32) -> Vec<u8> {
    #[cfg(feature = "console_error_panic_hook")]
    set_panic_hook(); // 尽早设置 panic hook

    #[cfg(feature = "debug_log")]
    console::log_1(&format!("[Rust] wasm_encrypt called: width={}, height={}, data_len={}", width, height, image_data_js.len()).into());

    // --- 修改点：移除 mut ---
    let image_data_input = image_data_js.to_vec();
    let mut output_data = vec![0u8; image_data_input.len()]; // 初始化为0

    if width == 0 || height == 0 { // 防止除以零或空图像
        #[cfg(feature = "debug_log")]
        console::error_1(&"[Rust] Error: Width or height is zero.".into());
        return output_data; // 或者 image_data_input 如果希望返回原图
    }

    let curve = gilbert2d_internal(width, height);
    let num_pixels = (width * height) as usize;

    if curve.len() != num_pixels {
        #[cfg(feature = "debug_log")]
        console::error_1(&format!("[Rust] Error: Curve length {} does not match num_pixels {}.", curve.len(), num_pixels).into());
        // 这种情况下，后续处理几乎肯定是错的，可以提前返回
        // 为了安全，可以用原始数据填充 output_data 或返回错误
        // 这里简单返回当前的 output_data (全黑或部分处理)
        return output_data;
    }


    let offset_float = ((5.0_f64.sqrt() - 1.0) / 2.0) * num_pixels as f64;
    let offset = offset_float.round() as usize;

    #[cfg(feature = "debug_log")]
    console::log_1(&format!("[Rust] num_pixels={}, offset={}", num_pixels, offset).into());


    for i in 0..num_pixels {
        // 检查 i 是否会超出 curve 的范围 (理论上不应该，如果 curve.len() == num_pixels)
        if i >= curve.len() || ((i + offset) % num_pixels) >= curve.len() {
             #[cfg(feature = "debug_log")]
            console::error_1(&format!("[Rust] Error: Index out of bounds for curve. i={}, offset={}, num_pixels={}, curve_len={}", i, offset, num_pixels, curve.len()).into());
            continue; // 跳过这个像素的处理
        }

        let old_pos_tuple = curve[i];
        let new_pos_index = (i + offset) % num_pixels;
        let new_pos_tuple = curve[new_pos_index];

        let old_p_base = (old_pos_tuple.0 + old_pos_tuple.1 * width) * 4;
        let new_p_base = (new_pos_tuple.0 + new_pos_tuple.1 * width) * 4;

        // 确保索引在范围内
        if old_p_base as usize + 3 < image_data_input.len() && new_p_base as usize + 3 < output_data.len() {
            output_data[(new_p_base as usize)..(new_p_base as usize + 4)]
                .copy_from_slice(&image_data_input[(old_p_base as usize)..(old_p_base as usize + 4)]);
        } else {
            #[cfg(feature = "debug_log")]
            console::error_1(&format!(
                "[Rust] Error: Pixel index out of bounds. old_pos=({},{}), new_pos=({},{}), old_p_base={}, new_p_base={}, data_len={}",
                old_pos_tuple.0, old_pos_tuple.1, new_pos_tuple.0, new_pos_tuple.1, old_p_base, new_p_base, image_data_input.len()
            ).into());
        }
    }
    output_data
}

#[wasm_bindgen]
pub fn wasm_decrypt(image_data_js: &[u8], width: u32, height: u32) -> Vec<u8> {
    #[cfg(feature = "console_error_panic_hook")]
    set_panic_hook();

    #[cfg(feature = "debug_log")]
    console::log_1(&format!("[Rust] wasm_decrypt called: width={}, height={}, data_len={}", width, height, image_data_js.len()).into());
    
    // --- 修改点：移除 mut ---
    let image_data_input = image_data_js.to_vec();
    let mut output_data = vec![0u8; image_data_input.len()];

    if width == 0 || height == 0 {
        #[cfg(feature = "debug_log")]
        console::error_1(&"[Rust] Error: Width or height is zero for decrypt.".into());
        return output_data;
    }

    let curve = gilbert2d_internal(width, height);
    let num_pixels = (width * height) as usize;

    if curve.len() != num_pixels {
        #[cfg(feature = "debug_log")]
        console::error_1(&format!("[Rust] Error: Curve length {} does not match num_pixels {} in decrypt.", curve.len(), num_pixels).into());
        return output_data;
    }

    let offset_float = ((5.0_f64.sqrt() - 1.0) / 2.0) * num_pixels as f64;
    let offset = offset_float.round() as usize;

    #[cfg(feature = "debug_log")]
    console::log_1(&format!("[Rust] Decrypt: num_pixels={}, offset={}", num_pixels, offset).into());

    for i in 0..num_pixels {
        if i >= curve.len() || ((i + offset) % num_pixels) >= curve.len() {
             #[cfg(feature = "debug_log")]
            console::error_1(&format!("[Rust] Error Decrypt: Index out of bounds for curve. i={}, offset={}, num_pixels={}, curve_len={}", i, offset, num_pixels, curve.len()).into());
            continue;
        }

        let old_pos_tuple = curve[i]; // 在解密时，这代表目标位置
        let new_pos_index = (i + offset) % num_pixels;
        let new_pos_tuple = curve[new_pos_index]; // 在解密时，这代表源数据中的位置

        // JS: imgdata2.data.set(imgdata.data.slice(new_p, new_p + 4), old_p)
        // Rust: output_data[old_p] = image_data_input[new_p]

        let target_p_base = (old_pos_tuple.0 + old_pos_tuple.1 * width) * 4;
        let source_p_base = (new_pos_tuple.0 + new_pos_tuple.1 * width) * 4;

        if source_p_base as usize + 3 < image_data_input.len() && target_p_base as usize + 3 < output_data.len() {
            output_data[(target_p_base as usize)..(target_p_base as usize + 4)]
                .copy_from_slice(&image_data_input[(source_p_base as usize)..(source_p_base as usize + 4)]);
        } else {
             #[cfg(feature = "debug_log")]
            console::error_1(&format!(
                "[Rust] Error Decrypt: Pixel index out of bounds. target_pos=({},{}), source_pos=({},{}), target_p_base={}, source_p_base={}, data_len={}",
                old_pos_tuple.0, old_pos_tuple.1, new_pos_tuple.0, new_pos_tuple.1, target_p_base, source_p_base, image_data_input.len()
            ).into());
        }
    }
    output_data
}